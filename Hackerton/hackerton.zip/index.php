<?
require_once("html_fns.php");
//session_start();
//if($_SESSION("user_email"))
//{

//}
//else
//{
	login_form();
//}
?>