<!DOCTYPE HTML>
<html>
	<head>
		<title>Soul Street</title>
		<meta charset='UTF-8' />
		<meta name='viewport' content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no' />
		<meta name='format-detection' content='telephone=no' />
		<link rel="stylesheet" type="text/css" href="./css/common.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://dinbror.dk/bpopup/assets/jquery.bpopup-0.9.4.min.js"></script>
		<script src="http://dinbror.dk/bpopup/assets/jquery.easing.1.3.js"></script>
		
		<!--popup
		<script type="text/javascript">
			;(function($) {
        		$(function() {
            		$('#login_btn').bind('click', function(e) {
                		e.preventDefault();
                		$('#login_form').bPopup();
            		});
        		});
    		})(jQuery);
		</script>-->

		<!--facebook-->
		<script>
		  window.fbAsyncInit = function() {
		    FB.init({
		      appId      : '389185827938088',
		      xfbml      : true,
		      version    : 'v2.4'
		    });
		  };

		  (function(d, s, id){
		     var js, fjs = d.getElementsByTagName(s)[0];
		     if (d.getElementById(id)) {return;}
		     js = d.createElement(s); js.id = id;
		     js.src = "//connect.facebook.net/en_US/sdk.js";
		     fjs.parentNode.insertBefore(js, fjs);
		   }(document, 'script', 'facebook-jssdk'));
		</script>
	</head>

	<body>
		<div class='container'>
			<div class='navbar'>
					<a href="index.php"><div id="logo">로그인</div></a>
			</div>
		</div>
		