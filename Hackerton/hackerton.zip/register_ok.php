<?
require_once("html_fns.php");
register_ok();
?>